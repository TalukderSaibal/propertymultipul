<?php
// This is for Unit section

return [

    // common text
    'golden_tower' => 'Golden Tower',
    'cancel' => 'Cancel',
    'created' => 'Created',

    // Unit Add
    'unit_add' => 'Add New Unit',
    'unit_list' => 'Unit List',
    'floor_no' => '* Floor No :',
    'unit_no' => '* Unit No :',

    // Unit Edit
    'unit_update' => 'Update Unit',
    'unit_created' => 'Update',

    //Unit List
    'unit_add' => 'Add Unit',
    'floor_no' => 'Floor No',
    'unit_no' => 'Unit No',
    'unit_action' => 'Action',
    'unit_edit' => 'Edit',
    'unit_delete' => 'Delete',
];
