<?php

return [

    // employee salary add & view
    
    'e_l_r' => 'Employee Leave Request',
    'l_r_l' => 'Leave Request List',
    'r_date' => 'Requested Date',
    'name' => 'Name',
    'designation' => 'Designation',
    'd_o_l' => 'Days of leave',
    'l_status' => 'Leave Status',
    'action' => 'Action',

];