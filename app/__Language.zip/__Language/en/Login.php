<?php
// This is for Login/ Registrationn/ Forget PASSWORD_BCRYPT

return [

    //Login Page
    'welcome' => 'Welcome Back !',
    'continue' => 'Sign in to continue to Upzet.',
    'username' => 'Username',
    'password' => 'Password',
    'remember' => 'Remember me',
    'forgot' => 'Forgot your password?',
    'login' => 'Log In',
    'account' => "Don't have an account ?",
    'signby' => 'Property Management. Crafted with',
    'sign_with' => 'by Therssoftware',

    //Reset Pass
    'reset' => 'Reset Password',
    'reset_with' => 'Reset your Password with Upzet.',
    'f_password' => 'Password',
    'f_con_pass' => 'Confirm Password',
    'f_btn' => 'Reset Password',
    'f_success' => 'Password Reset Successfully!',
    'f_login' => "Login",
    'signby' => 'Property Management. Crafted with',
    'sign_with' => 'by Therssoftware',

    //Forgot Pass
    'email' => 'Eamil',
    'send_email' => 'Send Email',

    //Forgot Pass
    'resend_link' => 'Do you want to resend password reset link?',
    'send_email' => 'Send Email',

];
