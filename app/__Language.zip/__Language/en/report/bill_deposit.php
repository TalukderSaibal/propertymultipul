<?php

return [

    // rented report
    
    'b_report' => 'Bill Report',

    's_date' => 'Select Date',
    's_month' => 'Select Month',
    's_year' => 'Select Year',
    'submit' => 'Submit',
    'date' => 'Date',
    'b_type' => 'Bill Type',
    'month' => 'Month',
    'year' => 'Year',
    'total_amount' => 'Total Amount',
    'd_b' => 'Deposit Bank',
    'details' => 'Details',
];