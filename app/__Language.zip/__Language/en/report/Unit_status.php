<?php
// This is for Unit Status Report section

return [

    // common text
    'golden_tower' => 'Golden Tower',
    'cancel' => 'Cancel',
    'created' => 'Created',

    // Unit Status Head Info
    'unit_headname' => 'Unit Status Report',
    'unit_headreport' => 'Unit Status Report Form',
    'unit_headdetails' => 'K-Block,Mirpur-10,Dhaka-1216 <br>opu@gmail.com <br>1212121212',
    
    // Unit Status Info And Print Page
    'unit_floor' => 'Floor No',
    'unit_unit' => 'Unit No',
    'unit_status' => 'Status',

    'unit_booked' => 'Booked',
    'unit_avai' => 'Available',


    // Unit Status report page
    'unitre_status' => 'Select Status :',
    'unitre_submit' => 'Submit',
];
