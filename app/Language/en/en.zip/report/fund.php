<?php

return [

    // rented report
    
    'f_report' => 'Fund Report',

    'image' => 'Image',
    'date' => 'Date',
    'owner_name' => 'Owner Name',
    'month' => 'Month',
    'year' => 'Year',
    'purpose' => 'Purpose',
    'c_t' => 'Cost Title',
    'details' => 'Details',
    'r_b' => 'Remain Balance',
    'amount' => 'Amount',
    'm_c_s' => 'Maintaining Cost Status',
];